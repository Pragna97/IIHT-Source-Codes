# codemix-vanilla-nodejs
Template for project creation of NodeJS inside CodeMix

## Contents

The template project is just an example Hello World that guide you through the use of nodejs with the Expressjs framework to build a very simple web application that display the Hello World!!! Greeting

