package com.in28minutes.jpa.hibernate.demo.entity;

import javax.persistence.Column;
import javax.persistence.*;

@Entity
public class Review {
	@Id
	@GeneratedValue
	private Long id;
	

	private String description;
	
	@Enumerated(EnumType.STRING)
	private ReviewRating rating;
	
	@ManyToOne
	private Course course;
	
	
	public Course getCourse() {
		return course;
	}
	public void setCourse(Course course) {
		this.course = course;
	}
	public Review(ReviewRating rating, String description) {
		super();
		this.description = description;
		this.rating = rating;
	}
	public Review(){
		
	}
	public Long getId() {
		return id;
	}
	@Override
	public String toString() {
		return "Review : rate" +rating+" desc "+ description + "]";
	}
	public Review(String description)
	{
		this.description=description;
	}
	public String getdescription() {
		return description;
	}
	public void setdescription(String description) {
		this.description = description;
	}
	public ReviewRating getRating() {
		return rating;
	}
	public void setRating(ReviewRating rating) {
		this.rating = rating;
	}
	
}
